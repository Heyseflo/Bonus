class Voiture {
  constructor(marque, modele, annee, couleur) {
    this.marque = marque;
    this.modele = modele;
    this.annee = annee;
    this.couleur = couleur;
  }

  afficherDetails() {
    console.log("Détails de la voiture :");
    console.log("Marque :", this.marque);
    console.log("Modèle :", this.modele);
    console.log("Année de fabrication :", this.annee);
    console.log("Couleur :", this.couleur);
  }

let maVoiture = new Voiture("Peugeot", "308", 2013, "Grise");

maVoiture.afficherDetails();

class Garage {
  constructor() {
    this.voitures = [];
  }

  ajouterVoiture(voiture) {
    this.voitures.push(voiture);
  }

  afficherVoituresParAnnée(année) {
    const voituresAnnée = this.voitures.filter(voiture => voiture.année === année);
    console.log(`Voitures de l'année ${année}:`);
    voituresAnnée.forEach(voiture => console.log(`- ${voiture.marque}`));
  }
  afficherVoituresParMarque(marque) {
    const voituresMarque = this.voitures.filter(voiture => voiture.marque === marque);
    console.log(`Voitures de la marque ${marque}:`);
    voituresMarque.forEach(voiture => console.log(`- ${voiture.marque} (${voiture.année})`));
  }
  
  afficherVoituresParMarqueTroisLettres(troisLettres) {
    const voituresMarqueTroisLettres = this.voitures.filter(voiture => voiture.marque.includes(troisLettres));
    console.log(`Voitures dont la marque contient '${troisLettres}':`);
    voituresMarqueTroisLettres.forEach(voiture => console.log(`- ${voiture.marque} (${voiture.année})`));
  }
  
const garage = new Garage();

const nombreVoitures = parseInt(prompt("Combien de voitures souhaitez-vous ajouter au garage?"));
for (let i = 0; i < nombreVoitures; i++) {
  const marque = prompt("Marque de la voiture:");
  const année = parseInt(prompt("Année de la voiture:"));
  const voiture = new Voiture(marque, année);
  garage.ajouterVoiture(voiture);
}

const tableau = document.createElement('table');
const header = tableau.createTHead();
const row = header.insertRow();
const marqueHeader = row.insertCell();
marqueHeader.innerHTML = "Marque";
const annéeHeader = row.insertCell();
annéeHeader.innerHTML = "Année";

const body = tableau.createTBody();
garage.voitures.forEach(voiture => {
  const row = body.insertRow();
  const marqueCell = row.insertCell();
  marqueCell.innerHTML = voiture.marque;
  const annéeCell = row.insertCell();
  annéeCell.innerHTML = voiture.année;
});

document.body.appendChild(tableau);